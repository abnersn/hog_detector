#!/bin/bash

i=1
echo "processing files"
find -name *.jpg | while read p; do
    mv "$p" "image_$i.jpg"
    i=$((i+1))
done;
